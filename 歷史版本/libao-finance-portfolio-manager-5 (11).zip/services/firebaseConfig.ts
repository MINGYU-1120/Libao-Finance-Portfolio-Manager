
// This file is deprecated. Configuration is now managed in services/firebase.ts
